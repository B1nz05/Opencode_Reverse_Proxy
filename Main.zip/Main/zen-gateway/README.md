# zen-gateway（ogate）

本机 OpenAI 兼容网关：让外部 Agent 通过**真实 OpenCode 客户端**调用 Zen 免费模型。
不伪造身份、不绕过上游访问控制——所有请求都由 OpenCode Desktop 后台服务以您的真实登录身份发起。

## 工作原理

```
外部 Agent ──HTTP──> ogate (本文件, 127.0.0.1:8787/v1)
                        │ HTTP Basic（凭据读取自 %USERPROFILE%\.local\state\opencode\service.json）
                        ▼
         OpenCode Desktop 后台服务（127.0.0.1:<动态端口>）
                        │ 真实 opencode 客户端身份（agent=chat-api，所有工具被禁用）
                        ▼
         https://opencode.ai/inference/...（免费模型，结算到您的免费额度）
```

依赖组件：
- OpenCode Desktop 保持运行（它提供后台服务；服务端口/密码变化时网关会自动重新发现）
- Node.js ≥ 18（本机已装 v24）
- `C:\Users\MSI Modern\opencode.json` 中定义的 `chat-api` agent（网关用它把会话约束为纯文本，禁止 shell/read/edit 等一切工具）

## 启动 / 停止 / 卸载

**启动**（PowerShell）：
```powershell
powershell -ExecutionPolicy Bypass -File "C:\Users\MSI Modern\Documents\Default Project\zen-gateway\start.ps1"
# 或直接：
node "C:\Users\MSI Modern\Documents\Default Project\zen-gateway\ogate.mjs"
```

**停止**：在启动它的终端按 `Ctrl+C`；或：
```powershell
Get-NetTCPConnection -LocalPort 8787 -State Listen | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }
```

**卸载**：
1. 删除文件夹 `C:\Users\MSI Modern\Documents\Default Project\zen-gateway\`
2. 删除 `C:\Users\MSI Modern\opencode.json`（或仅删掉文件里的 `agents.chat-api` 段）
3. 无其他系统级残留（没装服务、没改注册表、PATH 未动）

## 环境变量（可选）

| 变量 | 默认 | 说明 |
|---|---|---|
| `OGATE_PORT` | 8787 | 监听端口 |
| `OGATE_HOST` | 127.0.0.1 | 监听地址（不要改成 0.0.0.0） |
| `OGATE_KEY` | 无 | 设置后，客户端必须发送 `Authorization: Bearer <key>` |
| `OGATE_AGENT` | chat-api | 请求使用的 OpenCode agent |
| `OGATE_DEFAULT_MODEL` | 列表第一个 | 调用方未指定 model 时的默认模型 |
| `OGATE_AGENTS` | chat-api,api-writer | 模型名 `@agent` 后缀路由的允许清单 |
| `OGATE_TIMEOUT_MS` | 300000 | 单请求超时 |
| `OGATE_KEEP_SESSIONS` | 关 | 设为 1 时不在完成后删除 OpenCode 会话 |

## 模型路由（`@agent` 后缀）

模型名支持 `@<agent名>` 后缀，把会话切换到 `C:\Users\MSI Modern\opencode.json`
里定义的对应 agent：

| 模型名写法 | agent | 能力 |
|---|---|---|
| `big-pickle` | chat-api | 纯文本（工具全禁） |
| `big-pickle@api-writer` | api-writer | **真写文件**：模型可见 `read`/`write`/`edit`/`glob` 工具，读/写只允许在 `C:\Users\MSI Modern\Downloads\AI Writer\Soloent\` 内；jail 外任何写入都会被权限拒绝（模型会收到 `Permission denied: edit`） |

- `/v1/models` 会为每个免费模型额外列出 `...@api-writer` 形式的条目（`owned_by: opencode/api-writer`）。
- 后缀名必须在 `OGATE_AGENTS` 清单内，否则返回 400。
- **安全机制基于 OpenCode 权限系统**，与模型无关——即使模型不听话、试图越界写盘，
  权限层也会直接拒绝，不依赖模型自觉。

## 外部 Agent 配置

| 设置 | 值 |
|---|---|
| Base URL | `http://127.0.0.1:8787/v1` |
| API Key | 任意值（默认不校验；推荐填 `public`） |
| Model | 从 `GET /v1/models` 取，当前包括（会有变动）：`big-pickle`、`space-bunny-free`、`mimo-v2.6-flash-free`、`deepseek-v4.1-flash-free`、`glm-5.3-flash-free`、`longcat-2.5-preview-free`、`nemotron-3.5-super-vl-free`、`nemotron-3.5-lightning-free`、`nemotron-3-ultra-free`、`beam-free` |

支持：`/v1/models`、`/v1/chat/completions`（流式 + 非流式，`reasoning_content` 会映射出来）、
`system` 与多轮上下文（自动拼接为对话文本）、分配了 `stream_options.include_usage` 时的 usage。

## 重要限制（如实告知）

1. **Tool Calling 兼容模式（默认开启）**：带 `tools`/`tool_choice` 的请求会被接受，
   工具定义被**忽略**、按纯文本回答。响应会如实标注：
   - 非流式：JSON 里的 `zen_gateway.tools_ignored: true`
   - 流式：响应头 `X-Zen-Tools-Ignored: 1`
   模型永远不会返回伪造的 `tool_calls`。后果：如果调用方 Agent 的核心功能依赖工具执行
   （如 Cline 的文件编辑、写作 Agent 的记忆检索/存稿），这些功能**不会真正发生**，
   只有文本生成可用。将 start.ps1 中的 `OGATE_STRIP_TOOLS` 行删除可恢复严格拒绝模式。
2. 每个请求会在 OpenCode 中创建一次性会话并在完成后自动删除（`OGATE_KEEP_SESSIONS=1` 可保留）。
3. OpenCode 免费层按 IP/账号配额限流；被 429/403 限制时错误会原样透传，不会自动绕过。
4. 网关依赖 OpenCode Desktop 的后台服务存活；关闭 Desktop 后网关会返回 502/503 并在服务恢复后自动重连。
