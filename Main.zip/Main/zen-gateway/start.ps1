param([int]$Port = 8787)
$env:OGATE_PORT = "$Port"
# Compatibility mode: accept requests that carry OpenAI tool definitions,
# ignore them and answer with text. The response discloses this (tools_ignored).
# Delete/comment the next line to restore strict 400 rejection instead.
$env:OGATE_STRIP_TOOLS = "1"
Write-Host "Starting zen-gateway on 127.0.0.1:$Port ..."
node "$PSScriptRoot\ogate.mjs"
