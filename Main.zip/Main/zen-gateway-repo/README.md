# zen-gateway

本机 OpenAI 兼容网关：让外部 Agent（Cline、自写脚本、任意 OpenAI SDK 客户端）
通过**真实 OpenCode 客户端**调用 OpenCode Zen 免费模型。

不伪造身份、不绕过上游访问控制——所有请求都由本机 OpenCode Desktop 后台服务
以您的真实登录身份发起，结算到您的免费额度。

## 前提条件（每台电脑都需要）

1. **OpenCode Desktop 已安装并登录**（网关依赖它的后台服务，端口和密码自动发现）
2. **Node.js ≥ 18**（`node --version` 检查）
3. Windows / PowerShell（脚本均为 .ps1）

> 如果 OpenCode Desktop 列表中看不到免费模型（如 `big-pickle`），说明该账号没有
> 可用的免费层，请先在 Desktop 里确认能正常对话。

## 安装（一条命令）

```powershell
git clone <本仓库地址>
cd zen-gateway-repo
powershell -ExecutionPolicy Bypass -File install.ps1
```

`install.ps1` 会把 `agents.json` 里定义的三个 agent **合并**进
`%USERPROFILE%\opencode.json`（已有配置会被保留，先做时间戳备份，可重复执行）。

安装完成后**重启一次 OpenCode Desktop**（或它的服务），让新 agent 生效。

## 启动 / 停止

```powershell
# 启动（保持窗口开着；Ctrl+C 停止）
powershell -ExecutionPolicy Bypass -File start.ps1

# 或后台停止
Get-NetTCPConnection -LocalPort 8787 -State Listen | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }
```

启动后验证：`curl http://127.0.0.1:8787/health`

## 外部 Agent 配置

| 设置 | 值 |
|---|---|
| Base URL | `http://127.0.0.1:8787/v1` |
| API Key | 任意值（默认不校验） |

### 模型路由（`@agent` 后缀）

| 模型名写法 | agent | 能力 |
|---|---|---|
| `big-pickle` | chat-api | 纯文本（工具全禁，最安全） |
| `big-pickle@api-writer` | api-writer | 真写文件：`read`/`write`/`edit`/`glob`，只允许在您设定的项目目录内 |
| `big-pickle@api-full` | api-full | **权限全开**：读写全盘、执行 shell、联网等全部工具 |

`@` 后缀跟在任意免费模型名后：`big-pickle`、`space-bunny-free`、`mimo-v2.6-flash-free`、
`deepseek-v4.1-flash-free`、`glm-5.3-flash-free`、`longcat-2.5-preview-free`、
`nemotron-3.5-super-vl-free`、`nemotron-3.5-lightning-free`、`nemotron-3-ultra-free`、`beam-free`。
（后缀名必须在 `OGATE_AGENTS` 清单内，否则 400。）

### 接入 opencode（在其他电脑复刻）

把本仓库的 GitHub 地址发给那台电脑上运行的 opencode agent，并说
“按照该仓库 README 在本机安装并启动 zen-gateway”。agent 需要做的只是
clone + 运行 `install.ps1` + 重启 Desktop + 运行 `start.ps1`。

## 环境变量（可选）

| 变量 | 默认 | 说明 |
|---|---|---|
| `OGATE_PORT` | 8787 | 监听端口 |
| `OGATE_HOST` | 127.0.0.1 | 监听地址（不要改成 0.0.0.0） |
| `OGATE_KEY` | 无 | 设置后客户端必须带 `Authorization: Bearer <key>` |
| `OGATE_AGENTS` | chat-api,api-writer,api-full | `@agent` 路由白名单 |
| `OGATE_DEFAULT_MODEL` | 列表第一个 | 未指定 model 时的默认模型 |
| `OGATE_STRIP_TOOLS` | 1（start.ps1 里） | 带 `tools` 的请求被接受但工具被忽略、按纯文本回答 |
| `OGATE_KEEP_SESSIONS` | 关 | 设为 1 时完成后不删除 OpenCode 会话 |

## 安全须知（请务必阅读）

1. **`api-full` 权限全开**：经网关发出的请求可读写全盘任意文件（含 `.env`、SSH 密钥等敏感文件）、
   执行任意 shell 命令、联网。默认网关**不校验 API Key**——本机任何程序都能调用它。
   如需收紧：在 `start.ps1` 加 `$env:OGATE_KEY = "<随机密钥>"`，或删除 `opencode.json`
   里的 `api-full` agent。
2. **只绑 127.0.0.1**，不暴露局域网/公网。
3. **Tool Calling 兼容模式（默认）**：带 `tools`/`tool_choice` 的请求（如 Cline 发出的）
   工具定义被忽略、按纯文本回答，响应如实标注 `zen_gateway.tools_ignored: true`
   （流式为响应头 `X-Zen-Tools-Ignored: 1`），**不会伪造 `tool_calls`**。
   需要真实 tool_calls 的客户端请使用 `@`-agent 路由：写入由 OpenCode 服务端真实完成，
   客户端只需发纯文本指令。Cline 自身的工具面板仍不可用（它依赖真正的 tool_calls 返回）。
4. 每个请求创建一次性 OpenCode 会话并在完成后自动删除（所以 OpenCode 界面里看到
   “session cannot be found” 属正常现象）。
5. 免费层按配额限流；429/403 会原样透传，不会自动绕过。

## 卸载

```powershell
powershell -ExecutionPolicy Bypass -File uninstall.ps1   # 从 opencode.json 移除三个 agent
# 然后停止网关进程并删除本文件夹即可，无其他系统级残留
```
