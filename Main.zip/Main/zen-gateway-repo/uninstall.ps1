# Removes the zen-gateway agents from %USERPROFILE%\opencode.json (keeps everything else).
# Also prints how to fully remove the gateway files.
$ErrorActionPreference = "Stop"
$target = Join-Path $env:USERPROFILE "opencode.json"
if (-not (Test-Path $target)) { Write-Host "No $target found - nothing to do."; exit 0 }

Copy-Item $target "$target.bak-$(Get-Date -Format yyyyMMdd-HHmmss)" -Force
$cfg = Get-Content $target -Raw | ConvertFrom-Json

foreach ($name in @("chat-api", "api-writer", "api-full")) {
  if ($cfg.agents -and $cfg.agents.PSObject.Properties[$name]) {
    $cfg.agents.PSObject.Properties.Remove($name)
    Write-Host "  agent removed: $name"
  }
}

[IO.File]::WriteAllText($target, ($cfg | ConvertTo-Json -Depth 24), [Text.UTF8Encoding]::new($false))
Write-Host ""
Write-Host "Removed agents. To finish uninstalling:"
Write-Host "  1. stop the gateway:  Get-NetTCPConnection -LocalPort 8787 -State Listen | ForEach-Object { Stop-Process -Id `$_.OwningProcess -Force }"
Write-Host "  2. delete this repo folder"
