# Installs the zen-gateway agents into %USERPROFILE%\opencode.json (merge, never overwrite).
# Idempotent: safe to run repeatedly. A timestamped backup is made before any change.
# Usage:  powershell -ExecutionPolicy Bypass -File install.ps1
$ErrorActionPreference = "Stop"

$repo    = $PSScriptRoot
$agents  = Get-Content (Join-Path $repo "agents.json") -Raw | ConvertFrom-Json
$target  = Join-Path $env:USERPROFILE "opencode.json"

# api-writer is a path-jailed template: expand its relative rules into
# relative + absolute forms for THIS machine's homedir, and emit an edit
# variant for each read rule. Deny-all stays first, allows last (required
# ordering so OpenCode actually registers the write tools).
$w = $agents."api-writer"
$abs = $env:USERPROFILE -replace "\\", "/"
$perms = @()
foreach ($r in $w.permissions) {
  if ($r.resource -like "Downloads/*") {
    $perms += $r
    $a = $r.PSObject.Copy(); $a.resource = "$abs/$($r.resource)"; $perms += $a
    $e = $r.PSObject.Copy(); $e.action = "edit";               $perms += $e
    $e2 = $r.PSObject.Copy(); $e2.action = "edit"; $e2.resource = "$abs/$($r.resource)"; $perms += $e2
  } else { $perms += $r }
}
$w.permissions = $perms
$w.description = $w.description -replace "<HOMEDIR>", $env:USERPROFILE

# load or create config
$cfg = if (Test-Path $target) {
  Copy-Item $target "$target.bak-$(Get-Date -Format yyyyMMdd-HHmmss)" -Force
  Get-Content $target -Raw | ConvertFrom-Json
} else { [pscustomobject]@{} }

if (-not ($cfg.PSObject.Properties["agents"])) {
  $cfg | Add-Member -NotePropertyName agents -NotePropertyValue ([pscustomobject]@{})
}

foreach ($prop in $agents.PSObject.Properties) {
  $name = $prop.Name
  $val  = if ($name -eq "api-writer") { $w } else { $prop.Value }
  if ($cfg.agents.PSObject.Properties[$name]) {
    $cfg.agents.$name = $val
  } else {
    $cfg.agents | Add-Member -NotePropertyName $name -NotePropertyValue $val
  }
  Write-Host "  agent installed: $name"
}

[IO.File]::WriteAllText($target, ($cfg | ConvertTo-Json -Depth 24), [Text.UTF8Encoding]::new($false))
Write-Host ""
Write-Host "Wrote $target"
Write-Host "Next: restart OpenCode Desktop, then:  powershell -ExecutionPolicy Bypass -File start.ps1"
