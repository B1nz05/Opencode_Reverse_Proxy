# Starts the zen-gateway. Requires OpenCode Desktop to be running and logged in.
# Usage:  powershell -ExecutionPolicy Bypass -File start.ps1
# Sanitizing Tools-format requests by default (they are accepted but answered as plain text).

$env:OGATE_STRIP_TOOLS = "1"

node (Join-Path $PSScriptRoot "ogate.mjs")
