# Removes opencode-reverse-proxy from this machine.
#
#   powershell -ExecutionPolicy Bypass -File scripts\uninstall.ps1
#   powershell -ExecutionPolicy Bypass -File scripts\uninstall.ps1 -IncludeLegacy
#
# - Stops the gateway.
# - Removes the orp-chat / orp-writer / orp-full agents from the global config.
# - With -IncludeLegacy, also removes stale chat-api / api-writer / api-full agents
#   from ~/opencode.json (the pre-rename layout).
# - Leaves the writer sandbox folder and the skill directory in place.

param(
    [switch]$IncludeLegacy
)

. (Join-Path $PSScriptRoot "lib.ps1")

Write-Host ""
Write-Host "opencode-reverse-proxy - uninstall"
Write-Host "=================================="

# --- stop the gateway -----------------------------------------------------
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "stop.ps1") | Out-Null
Write-Step "gateway stopped"

$names = @("orp-chat", "orp-writer", "orp-full")

function Remove-OrpAgents {
    param([string]$Path, [string[]]$AgentNames)

    if (-not (Test-Path $Path)) { return }

    $raw = Get-Content $Path -Raw
    if (-not $raw.Trim()) { return }

    try {
        $cfg = $raw | ConvertFrom-Json
    } catch {
        Write-Host "  Skipped $Path (not valid JSON)" -ForegroundColor Yellow
        return
    }

    if (-not $cfg.agents) { return }

    $removed = @()
    foreach ($n in $AgentNames) {
        if ($cfg.agents.PSObject.Properties[$n]) {
            $cfg.agents.PSObject.Properties.Remove($n)
            $removed += $n
        }
    }
    if ($removed.Count -eq 0) { return }

    Copy-Item $Path "$Path.bak-$(Get-Date -Format yyyyMMdd-HHmmss)" -Force
    [IO.File]::WriteAllText($Path, ($cfg | ConvertTo-Json -Depth 32), [Text.UTF8Encoding]::new($false))
    Write-Step "removed from $Path : $($removed -join ', ')"
}

Remove-OrpAgents -Path (Get-OpenCodeConfigPath) -AgentNames $names

if ($IncludeLegacy) {
    Remove-OrpAgents -Path (Get-LegacyConfigPath) -AgentNames @("orp-chat", "orp-writer", "orp-full", "chat-api", "api-writer", "api-full")
}

# --- restart so the removal takes effect ----------------------------------
$cli = Get-OpenCodeCli
if ($cli) {
    & $cli service restart 2>&1 | Out-Null
    Write-Step "OpenCode service restarted"
} else {
    Write-Host "  Restart OpenCode Desktop manually so the agents disappear." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Agents removed."
Write-Host "Still on disk (delete manually if you want them gone):"
Write-Host "  - the skill folder containing these scripts"
Write-Host "  - $(Join-Path (Get-DownloadsPath) 'Opencode Reverse Proxy')"
Write-Host "  - $(Get-OrpStateDir)  (logs and pid file)"
Write-Host ""
