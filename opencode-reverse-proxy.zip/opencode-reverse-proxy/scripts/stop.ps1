# Stops the opencode-reverse-proxy gateway.
#
#   powershell -ExecutionPolicy Bypass -File scripts\stop.ps1
#
# Prefers the recorded PID, and falls back to whatever is listening on the port.

param(
    [int]$Port = 8787
)

. (Join-Path $PSScriptRoot "lib.ps1")

$stateDir = Get-OrpStateDir
$pidFile = Join-Path $stateDir "gateway.pid"

Write-Host ""
Write-Host "opencode-reverse-proxy - stop"
Write-Host "============================="

$stopped = $false

if (Test-Path $pidFile) {
    $recorded = (Get-Content $pidFile -Raw).Trim()
    $proc = Get-Process -Id $recorded -ErrorAction SilentlyContinue
    if ($proc -and $proc.ProcessName -eq "node") {
        Stop-Process -Id $proc.Id -Force
        Write-Step "stopped PID $($proc.Id)"
        $stopped = $true
    }
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
}

foreach ($conn in (Get-OrpListener -Port $Port)) {
    $proc = Get-Process -Id $conn.OwningProcess -ErrorAction SilentlyContinue
    if ($proc -and $proc.ProcessName -eq "node") {
        Stop-Process -Id $proc.Id -Force
        Write-Step "stopped PID $($proc.Id) (port $Port)"
        $stopped = $true
    }
}

if (-not $stopped) {
    Write-Host "  Nothing was running."
} else {
    Start-Sleep -Milliseconds 500
    if (Get-OrpListener -Port $Port) {
        Write-Host "  Port $Port is still held by another process." -ForegroundColor Yellow
    } else {
        Write-Host "  Gateway stopped."
    }
}
Write-Host ""
