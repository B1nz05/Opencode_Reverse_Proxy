# Starts the opencode-reverse-proxy gateway in the background and waits until it is healthy.
#
#   powershell -ExecutionPolicy Bypass -File scripts\start.ps1
#   powershell -ExecutionPolicy Bypass -File scripts\start.ps1 -Port 9000 -Key "secret"
#
# The process is detached, so this returns as soon as the gateway answers /health.

param(
    [int]$Port = 8787,
    [string]$Host_ = "127.0.0.1",
    [string]$Key = "",
    [string]$DefaultModel = "",
    [int]$TimeoutSec = 30
)

. (Join-Path $PSScriptRoot "lib.ps1")

$root = Get-OrpRoot
$gateway = Join-Path $root "gateway.mjs"
$stateDir = Get-OrpStateDir
$outLog = Join-Path $stateDir "gateway.out.log"
$errLog = Join-Path $stateDir "gateway.err.log"
$pidFile = Join-Path $stateDir "gateway.pid"

Write-Host ""
Write-Host "opencode-reverse-proxy - start"
Write-Host "=============================="

if (-not (Test-Path $gateway)) {
    throw "gateway.mjs is missing at $gateway"
}

$existing = Get-OrpListener -Port $Port
if ($existing) {
    Write-Host "  Port $Port is already in use (PID $($existing[0].OwningProcess))." -ForegroundColor Yellow
    if (Test-OrpHealth -Port $Port) {
        Write-Host "  An opencode-reverse-proxy instance is already running there."
        exit 0
    }
    throw "Port $Port is taken by another program. Stop it or choose a different -Port."
}

if (-not (Get-OpenCodeCli) -and -not (Test-Path (Join-Path $env:USERPROFILE ".local\state\opencode\service.json"))) {
    throw "OpenCode Desktop does not appear to be installed or running. Start OpenCode Desktop first: the gateway routes through its background service."
}

$nodeExe = (Get-Command node).Source

$env:ORP_STRIP_TOOLS = "1"
$env:ORP_PORT = "$Port"
$env:ORP_HOST = $Host_
if ($Key) { $env:ORP_KEY = $Key }
if ($DefaultModel) { $env:ORP_DEFAULT_MODEL = $DefaultModel }

# Launch fully detached: a bare Start-Process still ties the child to this
# console's job object, which keeps the caller (and any agent driving it)
# blocked until the gateway exits. cmd's `start` breaks that link.
$cmdLine = 'start "" /b "{0}" "{1}" > "{2}" 2> "{3}"' -f $nodeExe, $gateway, $outLog, $errLog
$proc = Start-Process -FilePath "cmd.exe" -ArgumentList "/c", $cmdLine -WindowStyle Hidden -PassThru
$proc.WaitForExit(5000) | Out-Null

$deadline = (Get-Date).AddSeconds($TimeoutSec)
$gatewayPid = $null
while ((Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 400
    if (Test-OrpHealth -Port $Port) {
        $conn = Get-OrpListener -Port $Port
        if ($conn) { $gatewayPid = $conn[0].OwningProcess }
        break
    }
    if (Test-Path $errLog) {
        $err = Get-Content $errLog -Raw
        if ($err -and $err -match "EADDRINUSE|Error:") {
            throw "The gateway failed to start:`n$err"
        }
    }
}

if (-not (Test-OrpHealth -Port $Port)) {
    $err = if (Test-Path $errLog) { Get-Content $errLog -Raw } else { "" }
    throw "The gateway did not become healthy within $TimeoutSec seconds.`n$err"
}

if ($gatewayPid) {
    Set-Content -Path $pidFile -Value $gatewayPid -Encoding ASCII
    Write-Step "started PID $gatewayPid"
}

Write-Host ""
Write-Host "  Gateway is up: http://${Host_}:$Port/v1"
Write-Host "  Base URL     : http://${Host_}:$Port/v1"
Write-Host "  API Key      : $(if ($Key) { '(the -Key value you passed)' } else { 'any value (no key required)' })"
Write-Host "  Logs         : $outLog"
Write-Host ""
Write-Host "  Stop with    : powershell -ExecutionPolicy Bypass -File scripts\stop.ps1"
Write-Host ""
exit 0
