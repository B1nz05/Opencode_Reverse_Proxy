# Shared helpers for opencode-reverse-proxy scripts.
# Dot-source this file: . (Join-Path $PSScriptRoot "lib.ps1")

$ErrorActionPreference = "Stop"

# The skill root is the parent of the scripts/ directory.
function Get-OrpRoot {
    return (Split-Path -Parent $PSScriptRoot)
}

# OpenCode global configuration file (V2). Honors XDG_CONFIG_HOME.
function Get-OpenCodeConfigPath {
    if ($env:XDG_CONFIG_HOME) {
        return (Join-Path $env:XDG_CONFIG_HOME "opencode\opencode.json")
    }
    return (Join-Path $env:USERPROFILE ".config\opencode\opencode.json")
}

# Legacy per-home config that overrides the global one via ancestor discovery.
function Get-LegacyConfigPath {
    return (Join-Path $env:USERPROFILE "opencode.json")
}

# Resolve the real Downloads folder (locale independent), falling back to the default.
function Get-DownloadsPath {
    try {
        $shell = New-Object -ComObject Shell.Application
        $p = $shell.Namespace('shell:Downloads').Self.Path
        if ($p -and (Test-Path $p)) { return $p }
    } catch { }
    return (Join-Path $env:USERPROFILE "Downloads")
}

# Locate the OpenCode CLI shipped with the desktop app. Returns $null if absent.
function Get-OpenCodeCli {
    $candidates = @()

    $cmd = Get-Command opencode -ErrorAction SilentlyContinue
    if ($cmd) { $candidates += $cmd.Source }

    $cliRoot = Join-Path $env:APPDATA "ai.opencode.desktop\cli"
    if (Test-Path $cliRoot) {
        $candidates += Get-ChildItem $cliRoot -Directory -ErrorAction SilentlyContinue |
            Sort-Object Name -Descending |
            ForEach-Object { Join-Path $_.FullName "opencode-cli.exe" }
    }

    $localCli = Join-Path $env:LOCALAPPDATA "Programs\opencode\opencode-cli.exe"
    $candidates += $localCli

    foreach ($c in $candidates) {
        if ($c -and (Test-Path $c)) { return $c }
    }
    return $null
}

# Convert a path to the forward-slash form OpenCode permission rules use.
function ConvertTo-OrpRulePath {
    param([Parameter(Mandatory = $true)][string]$Path)
    return ($Path -replace "\\", "/")
}

# HTTP helper that decodes responses as UTF-8 (PowerShell 5.1 otherwise guesses Latin-1).
function Invoke-OrpJson {
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [string]$Method = "GET",
        [string]$Body,
        [int]$TimeoutSec = 300
    )

    $req = [Net.HttpWebRequest]::Create($Uri)
    $req.Method = $Method
    $req.Timeout = $TimeoutSec * 1000
    $req.ReadWriteTimeout = $TimeoutSec * 1000
    $req.Accept = "application/json"

    if ($PSBoundParameters.ContainsKey("Body") -and $null -ne $Body) {
        $bytes = [Text.Encoding]::UTF8.GetBytes($Body)
        $req.ContentType = "application/json; charset=utf-8"
        $req.ContentLength = $bytes.Length
        $stream = $req.GetRequestStream()
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Close()
    }

    $status = 200
    try {
        $res = $req.GetResponse()
    } catch [Net.WebException] {
        $res = $_.Exception.Response
        if (-not $res) { throw }
        $status = [int]$res.StatusCode
    }

    $reader = New-Object IO.StreamReader($res.GetResponseStream(), [Text.Encoding]::UTF8)
    $text = $reader.ReadToEnd()
    $reader.Close()
    $res.Close()

    $parsed = $null
    if ($text) {
        try { $parsed = $text | ConvertFrom-Json } catch { $parsed = $text }
    }

    return [pscustomobject]@{ Status = $status; Data = $parsed; Raw = $text }
}

# Read raw SSE bytes as UTF-8 text.
function Invoke-OrpSse {
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [Parameter(Mandatory = $true)][string]$Body,
        [int]$TimeoutSec = 300
    )

    $req = [Net.HttpWebRequest]::Create($Uri)
    $req.Method = "POST"
    $req.Timeout = $TimeoutSec * 1000
    $req.ReadWriteTimeout = $TimeoutSec * 1000
    $req.Accept = "text/event-stream"

    $bytes = [Text.Encoding]::UTF8.GetBytes($Body)
    $req.ContentType = "application/json; charset=utf-8"
    $req.ContentLength = $bytes.Length
    $stream = $req.GetRequestStream()
    $stream.Write($bytes, 0, $bytes.Length)
    $stream.Close()

    $res = $req.GetResponse()
    $reader = New-Object IO.StreamReader($res.GetResponseStream(), [Text.Encoding]::UTF8)
    $text = $reader.ReadToEnd()
    $reader.Close()
    $res.Close()

    return $text
}

# Port state helpers.
function Get-OrpListener {
    param([int]$Port = 8787)
    return Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
}

function Test-OrpHealth {
    param([int]$Port = 8787, [int]$TimeoutSec = 3)
    try {
        $r = Invoke-OrpJson -Uri "http://127.0.0.1:$Port/health" -TimeoutSec $TimeoutSec
        return ($r.Status -eq 200 -and $r.Data.ok -eq $true)
    } catch {
        return $false
    }
}

# State directory for pid/log files.
function Get-OrpStateDir {
    $dir = Join-Path $env:LOCALAPPDATA "opencode-reverse-proxy"
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    return $dir
}

function Write-Step {
    param([string]$Message)
    Write-Host "  $Message"
}

function Write-Head {
    param([string]$Message)
    Write-Host ""
    Write-Host $Message
}
