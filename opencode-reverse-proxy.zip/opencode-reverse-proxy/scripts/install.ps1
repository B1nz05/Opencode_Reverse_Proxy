# Installs the opencode-reverse-proxy agents into the OpenCode global configuration.
#
#   powershell -ExecutionPolicy Bypass -File scripts\install.ps1
#
# - Creates the writer sandbox folder (~/Downloads/Opencode Reverse Proxy).
# - Merges the three agents into ~/.config/opencode/opencode.json (never overwrites
#   unrelated settings, makes a timestamped backup, safe to re-run).
# - Restarts the OpenCode background service so the agents take effect immediately.
# - Verifies the agents are registered by querying the running service.

param(
    [string]$WriterDir,
    [switch]$NoRestart
)

. (Join-Path $PSScriptRoot "lib.ps1")

$root = Get-OrpRoot
$agentsFile = Join-Path $root "agents.json"
$configPath = Get-OpenCodeConfigPath

Write-Host ""
Write-Host "opencode-reverse-proxy - install"
Write-Host "================================"

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    throw "Node.js was not found on PATH. Install Node.js 18 or newer, then re-run this script."
}
Write-Step ("node " + (node --version))

if (-not (Test-Path $agentsFile)) {
    throw "agents.json is missing next to this script (expected at $agentsFile)."
}
$agentsRaw = Get-Content $agentsFile -Raw

# --- writer sandbox -------------------------------------------------------
if (-not $WriterDir) {
    $WriterDir = Join-Path (Get-DownloadsPath) "Opencode Reverse Proxy"
}
$WriterDir = [IO.Path]::GetFullPath($WriterDir)
if (-not (Test-Path $WriterDir)) {
    New-Item -ItemType Directory -Force -Path $WriterDir | Out-Null
    Write-Step "created writer folder: $WriterDir"
} else {
    Write-Step "writer folder exists: $WriterDir"
}

# Stamp the sandbox path into the agent rules, in the forward-slash form
# OpenCode normalizes paths to before matching.
#
# OpenCode matches read/edit against a *Location-relative* path when the target
# is inside the session's working directory, and against the canonical absolute
# path when it is outside. The gateway's sessions use the service's working
# directory (normally the user's home), so we register BOTH forms: whichever one
# applies will match. Registering only the absolute form silently fails for
# paths under the home directory.
$writerRule = (ConvertTo-OrpRulePath $WriterDir).TrimEnd("/")
$agents = ($agentsRaw.Replace("__WRITER_DIR__", $writerRule)) | ConvertFrom-Json

$homeRule = (ConvertTo-OrpRulePath $env:USERPROFILE).TrimEnd("/")
$relativeRule = $null
if ($writerRule.StartsWith($homeRule + "/", [StringComparison]::OrdinalIgnoreCase)) {
    $relativeRule = $writerRule.Substring($homeRule.Length + 1)
}

$writerAgent = $agents.PSObject.Properties["orp-writer"]
if ($writerAgent -and $relativeRule) {
    $stamped = @()
    foreach ($rule in $writerAgent.Value.permissions) {
        $stamped += $rule
        if ($rule.effect -eq "allow" -and $rule.resource -eq "$writerRule/*") {
            $copy = $rule.PSObject.Copy()
            $copy.resource = "$relativeRule/*"
            $stamped += $copy
        }
    }
    $writerAgent.Value.permissions = $stamped
    Write-Step "writer rules: $writerRule/* (+ relative $relativeRule/*)"
} else {
    Write-Step "writer rules: $writerRule/*"
}

# --- config file ----------------------------------------------------------
$configDir = Split-Path -Parent $configPath
if (-not (Test-Path $configDir)) {
    New-Item -ItemType Directory -Force -Path $configDir | Out-Null
}

$cfg = $null
if (Test-Path $configPath) {
    $raw = Get-Content $configPath -Raw
    Copy-Item $configPath "$configPath.bak-$(Get-Date -Format yyyyMMdd-HHmmss)" -Force
    try {
        $cfg = $raw | ConvertFrom-Json
    } catch {
        if ($raw -match '(?m)^[ \t]*//' -or $raw -match '/\*') {
            throw "The existing config at $configPath contains comments (JSONC). OpenCode accepts that, but this installer cannot safely rewrite it. Remove the comments (or convert the file to plain JSON), then re-run. Nothing was changed."
        }
        throw "The existing config at $configPath is not valid JSON. Fix or move it, then re-run. Nothing was changed."
    }
    Write-Step "backed up existing config"
} else {
    $cfg = [pscustomobject]@{}
    Write-Step "no existing config, creating one"
}

if (-not $cfg.PSObject.Properties["schema"] -and -not $cfg.PSObject.Properties['$schema']) {
    $cfg | Add-Member -NotePropertyName '$schema' -NotePropertyValue "https://opencode.ai/config.json"
}

if (-not $cfg.PSObject.Properties["agents"]) {
    $cfg | Add-Member -NotePropertyName agents -NotePropertyValue ([pscustomobject]@{})
}

# --- install this folder as a global skill ---------------------------------
# So OpenCode agents can find and reuse it on this machine. Skipped when the
# folder already lives in the skills directory.
$skillId = "opencode-reverse-proxy"
$skillsRoot = if ($env:XDG_CONFIG_HOME) {
    Join-Path $env:XDG_CONFIG_HOME "opencode\skills"
} else {
    Join-Path $env:USERPROFILE ".config\opencode\skills"
}
$installedSkill = Join-Path $skillsRoot $skillId
if ((Get-OrpRoot) -ne $installedSkill) {
    if (Test-Path $installedSkill) {
        Remove-Item $installedSkill -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $installedSkill | Out-Null
    Get-ChildItem (Get-OrpRoot) -Force |
        Where-Object { $_.Name -notin @(".git", ".gitignore") -and $_.Name -notlike "*.bak-*" } |
        ForEach-Object { Copy-Item $_.FullName -Destination $installedSkill -Recurse -Force }
    Write-Step "skill installed: $installedSkill"
} else {
    Write-Step "running from the installed skill folder"
}

foreach ($prop in $agents.PSObject.Properties) {
    $name = $prop.Name
    if ($cfg.agents.PSObject.Properties[$name]) {
        $cfg.agents.$name = $prop.Value
        Write-Step "agent updated: $name"
    } else {
        $cfg.agents | Add-Member -NotePropertyName $name -NotePropertyValue $prop.Value
        Write-Step "agent installed: $name"
    }
}

[IO.File]::WriteAllText($configPath, ($cfg | ConvertTo-Json -Depth 32), [Text.UTF8Encoding]::new($false))
Write-Step "wrote $configPath"

# --- legacy config warning ------------------------------------------------
$legacy = Get-LegacyConfigPath
if (Test-Path $legacy) {
    try {
        $legacyCfg = Get-Content $legacy -Raw | ConvertFrom-Json
        $legacyAgents = @()
        foreach ($n in @("chat-api", "api-writer", "api-full", "orp-chat", "orp-writer", "orp-full")) {
            if ($legacyCfg.agents -and $legacyCfg.agents.PSObject.Properties[$n]) { $legacyAgents += $n }
        }
        if ($legacyAgents.Count -gt 0) {
            Write-Host ""
            Write-Host "  NOTE: $legacy still defines: $($legacyAgents -join ', ')" -ForegroundColor Yellow
            Write-Host "        That file wins over the global config for anything under $env:USERPROFILE." -ForegroundColor Yellow
            Write-Host "        Run scripts\uninstall.ps1 -IncludeLegacy to remove those stale agents." -ForegroundColor Yellow
        }
    } catch { }
}

# --- restart the service only if the agents did not register ---------------
# OpenCode hot-reloads configuration into the running service, so a restart is
# normally unnecessary. Restarting is also disruptive: it terminates any
# OpenCode session currently running, including the one that invoked this
# installer. So: verify first, restart only as a fallback, and never restart
# when -NoRestart was requested.
$verifyScript = Join-Path $PSScriptRoot "verify.ps1"

Write-Host ""
Write-Host "Verifying agent registration..."

& powershell -NoProfile -ExecutionPolicy Bypass -File $verifyScript -InstallOnly | Out-Host
$registered = ($LASTEXITCODE -eq 0)

if (-not $registered -and -not $NoRestart) {
    $cli = Get-OpenCodeCli
    if ($cli) {
        Write-Host ""
        Write-Host "  Agents did not register via hot reload; restarting the OpenCode service." -ForegroundColor Yellow
        Write-Host "  Note: this terminates any OpenCode session that is currently running." -ForegroundColor Yellow
        & $cli service restart 2>&1 | Out-Null
        Start-Sleep -Seconds 2
        & powershell -NoProfile -ExecutionPolicy Bypass -File $verifyScript -InstallOnly | Out-Host
        $registered = ($LASTEXITCODE -eq 0)
    } else {
        Write-Host ""
        Write-Host "  Could not locate opencode-cli. Restart OpenCode Desktop manually so the agents register." -ForegroundColor Yellow
    }
}

if (-not $registered) {
    Write-Host ""
    Write-Host "  The agents are not registered yet. Restart OpenCode Desktop from a normal" -ForegroundColor Yellow
    Write-Host "  PowerShell window, then run: powershell -ExecutionPolicy Bypass -File scripts\verify.ps1 -InstallOnly" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Done."
Write-Host "  Writer sandbox : $WriterDir"
Write-Host "  Config         : $configPath"
Write-Host "  Next           : powershell -ExecutionPolicy Bypass -File scripts\start.ps1"
Write-Host ""
