# Verifies an opencode-reverse-proxy installation.
#
#   powershell -ExecutionPolicy Bypass -File scripts\verify.ps1            # full check
#   powershell -ExecutionPolicy Bypass -File scripts\verify.ps1 -InstallOnly  # agents only
#   powershell -ExecutionPolicy Bypass -File scripts\verify.ps1 -Port 9000 -Model big-pickle
#
# Exit code 0 means every check passed.

param(
    [int]$Port = 8787,
    [string]$Model = "",
    [switch]$InstallOnly,
    [switch]$SkipWriteTest,
    [int]$TimeoutSec = 300
)

. (Join-Path $PSScriptRoot "lib.ps1")

$failures = @()
$checks = 0

function Check {
    param([string]$Name, [scriptblock]$Body)
    $script:checks++
    try {
        $result = & $Body
        if ($result -eq $false) {
            Write-Host ("  [FAIL] " + $Name) -ForegroundColor Red
            $script:failures += $Name
        } else {
            $detail = if ($result -is [string] -and $result) { " - $result" } else { "" }
            Write-Host ("  [ ok ] " + $Name + $detail) -ForegroundColor Green
        }
    } catch {
        Write-Host ("  [FAIL] " + $Name + " - " + $_.Exception.Message) -ForegroundColor Red
        $script:failures += $Name
    }
}

Write-Host ""
Write-Host "opencode-reverse-proxy - verify"
Write-Host "==============================="

# --- 1. Node ---------------------------------------------------------------
Check "node is available" {
    $v = (node --version) 2>$null
    if (-not $v) { return $false }
    $major = [int]($v.TrimStart("v").Split(".")[0])
    if ($major -lt 18) { throw "Node $v is too old, need 18+" }
    return $v
}

# --- 2. OpenCode service ---------------------------------------------------
$serviceJson = Join-Path $env:USERPROFILE ".local\state\opencode\service.json"

Check "OpenCode background service is running" {
    if (-not (Test-Path $serviceJson)) { throw "service.json not found - is OpenCode Desktop installed and running?" }
    $svc = Get-Content $serviceJson -Raw | ConvertFrom-Json
    if (-not $svc.url -or -not $svc.password) { throw "service.json is incomplete" }
    return $svc.url
}

# --- 3. Agents registered --------------------------------------------------
Check "agents orp-chat / orp-writer / orp-full are registered" {
    $svc = Get-Content $serviceJson -Raw | ConvertFrom-Json
    $auth = "Basic " + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("opencode:$($svc.password)"))
    $req = [Net.HttpWebRequest]::Create("$($svc.url)/api/agent")
    $req.Headers.Add("Authorization", $auth)
    $req.Timeout = 15000
    $res = $req.GetResponse()
    $reader = New-Object IO.StreamReader($res.GetResponseStream(), [Text.Encoding]::UTF8)
    $payload = $reader.ReadToEnd() | ConvertFrom-Json
    $reader.Close()
    $res.Close()

    $ids = @($payload.data | ForEach-Object { $_.id })
    $missing = @()
    foreach ($a in @("orp-chat", "orp-writer", "orp-full")) {
        if ($ids -notcontains $a) { $missing += $a }
    }
    if ($missing.Count -gt 0) {
        throw "missing: $($missing -join ', '). Restart the OpenCode service (or OpenCode Desktop) and re-check."
    }
    return ($ids | Where-Object { $_ -like "orp-*" }) -join ", "
}

if ($InstallOnly) {
    Write-Host ""
    if ($failures.Count -eq 0) {
        Write-Host "Install verified." -ForegroundColor Green
        exit 0
    }
    Write-Host "$($failures.Count) of $checks checks failed." -ForegroundColor Red
    exit 1
}

# --- 4. Gateway health -----------------------------------------------------
Check "gateway answers /health on port $Port" {
    $r = Invoke-OrpJson -Uri "http://127.0.0.1:$Port/health" -TimeoutSec 5
    if ($r.Status -ne 200) { throw "HTTP $($r.Status) - is the gateway started? (scripts\start.ps1)" }
    return $r.Data.opencodeService
}

# --- 5. Models -------------------------------------------------------------
$modelList = @()
Check "gateway lists free models" {
    $r = Invoke-OrpJson -Uri "http://127.0.0.1:$Port/v1/models" -TimeoutSec 30
    if ($r.Status -ne 200) { throw "HTTP $($r.Status)" }
    $script:modelList = @($r.Data.data | ForEach-Object { $_.id })
    if ($script:modelList.Count -eq 0) { throw "no models returned - is your OpenCode account on the free tier?" }
    return "$($script:modelList.Count) ids"
}

if (-not $Model) {
    $base = $modelList | Where-Object { $_ -notmatch "@" } | Select-Object -First 1
    $Model = if ($base) { $base } else { "" }
}

# --- 6. Plain chat (non-stream) -------------------------------------------
Check "non-stream chat via '$Model'" {
    if (-not $Model) { throw "no model available to test" }
    $body = @{
        model    = $Model
        messages = @(@{ role = "user"; content = "Reply with exactly: pong" })
    } | ConvertTo-Json -Depth 6
    $r = Invoke-OrpJson -Uri "http://127.0.0.1:$Port/v1/chat/completions" -Method POST -Body $body -TimeoutSec $TimeoutSec
    if ($r.Status -ne 200) { throw "HTTP $($r.Status): $($r.Raw)" }
    $text = $r.Data.choices[0].message.content
    if (-not $text) { throw "empty response" }
    return ($text -replace "\s+", " ").Trim()
}

# --- 7. UTF-8 round trip ---------------------------------------------------
Check "Chinese text survives the round trip" {
    if (-not $Model) { throw "no model available to test" }
    $body = @{
        model    = $Model
        messages = @(@{ role = "user"; content = "只回复两个字：你好" })
    } | ConvertTo-Json -Depth 6
    $r = Invoke-OrpJson -Uri "http://127.0.0.1:$Port/v1/chat/completions" -Method POST -Body $body -TimeoutSec $TimeoutSec
    if ($r.Status -ne 200) { throw "HTTP $($r.Status)" }
    $text = $r.Data.choices[0].message.content
    if ($text -notmatch "你好") { throw "response did not contain the expected characters: $text" }
    return "ok"
}

# --- 8. Streaming ----------------------------------------------------------
Check "streaming chat emits SSE chunks and [DONE]" {
    if (-not $Model) { throw "no model available to test" }
    $body = @{
        model    = $Model
        stream   = $true
        messages = @(@{ role = "user"; content = "Reply with exactly: pong" })
    } | ConvertTo-Json -Depth 6
    $raw = Invoke-OrpSse -Uri "http://127.0.0.1:$Port/v1/chat/completions" -Body $body -TimeoutSec $TimeoutSec
    $chunks = ($raw -split "`n" | Where-Object { $_ -match "^data: \{" }).Count
    if ($chunks -eq 0) { throw "no chunks received" }
    if (-not $raw.Contains("[DONE]")) { throw "stream did not end with [DONE]" }
    return "$chunks chunks"
}

# --- 9. Writer route -------------------------------------------------------
if (-not $SkipWriteTest) {
    $writerDir = Join-Path (Get-DownloadsPath) "Opencode Reverse Proxy"

    Check "orp-writer can create a file inside the sandbox" {
        if (-not $Model) { throw "no model available to test" }
        $target = Join-Path $writerDir "verify-probe.txt"
        if (Test-Path $target) { Remove-Item $target -Force }

        $fwd = ConvertTo-OrpRulePath $target
        $body = @{
            model    = "$Model@orp-writer"
            messages = @(@{
                role    = "user"
                content = "Use the write tool to create the file $fwd with exactly this one line of content: proxy write ok. Use that absolute path, do not try any other path."
            })
        } | ConvertTo-Json -Depth 6

        $r = Invoke-OrpJson -Uri "http://127.0.0.1:$Port/v1/chat/completions" -Method POST -Body $body -TimeoutSec $TimeoutSec
        if ($r.Status -ne 200) { throw "HTTP $($r.Status): $($r.Raw)" }
        if (-not (Test-Path $target)) {
            throw "the file was not created. Model said: $($r.Data.choices[0].message.content)"
        }
        Remove-Item $target -Force
        return "sandbox write ok"
    }

    Check "orp-writer refuses writes outside the sandbox" {
        if (-not $Model) { throw "no model available to test" }
        $outside = Join-Path $env:USERPROFILE "orp-should-not-exist.txt"
        if (Test-Path $outside) { Remove-Item $outside -Force }

        $fwd = ConvertTo-OrpRulePath $outside
        $body = @{
            model    = "$Model@orp-writer"
            messages = @(@{
                role    = "user"
                content = "Use the write tool to create the file $fwd with the content: escape test"
            })
        } | ConvertTo-Json -Depth 6

        $null = Invoke-OrpJson -Uri "http://127.0.0.1:$Port/v1/chat/completions" -Method POST -Body $body -TimeoutSec $TimeoutSec
        if (Test-Path $outside) {
            Remove-Item $outside -Force
            throw "the sandbox was breached - a file was written outside $writerDir"
        }
        return "correctly blocked"
    }
}

Write-Host ""
if ($failures.Count -eq 0) {
    Write-Host "All $checks checks passed." -ForegroundColor Green
    Write-Host ""
    Write-Host "  Base URL : http://127.0.0.1:$Port/v1"
    Write-Host "  API Key  : any value (no key required unless you started with -Key)"
    Write-Host "  Model    : $Model  (add @orp-writer or @orp-full to change permissions)"
    Write-Host ""
    exit 0
}

Write-Host "$($failures.Count) of $checks checks failed:" -ForegroundColor Red
foreach ($f in $failures) { Write-Host "  - $f" -ForegroundColor Red }
Write-Host ""
Write-Host "See references\troubleshooting.md"
exit 1
