---
name: OpenCode Reverse Proxy
description: Install, start, verify, troubleshoot, or remove a local OpenAI-compatible gateway on Windows that routes requests through the genuine OpenCode Desktop client to free Zen models. Use when the user wants to expose OpenCode models to an external OpenAI SDK client, Cline, or a custom script, or mentions opencode-reverse-proxy, the local gateway on port 8787, or the orp- agents.
---

# OpenCode Reverse Proxy

A local OpenAI-compatible HTTP gateway. External clients call
`http://127.0.0.1:8787/v1` with any OpenAI SDK; the gateway forwards the request
through the **genuine OpenCode Desktop background service**, so the call is made
under the user's real login and bills to their free Zen quota. No credentials are
copied, no identity is spoofed.

```
external client → gateway (127.0.0.1:8787/v1) → OpenCode Desktop service → opencode.ai free models
```

**Windows only.** Requires Node.js 18+ and a running, logged-in OpenCode Desktop.

## Layout

```
opencode-reverse-proxy/       <- this folder IS the skill
├── SKILL.md
├── README.md
├── gateway.mjs               <- the gateway
├── agents.json               <- agent templates (__WRITER_DIR__ is stamped at install)
├── scripts/
│   ├── lib.ps1               <- shared helpers
│   ├── install.ps1
│   ├── start.ps1
│   ├── stop.ps1
│   ├── verify.ps1
│   └── uninstall.ps1
└── references/
    ├── client-setup.md
    ├── permissions.md
    └── troubleshooting.md
```

## Naming

Use these names consistently; do not invent variants.

| Thing | Value |
|---|---|
| Product / skill ID | `opencode-reverse-proxy` |
| Env var prefix | `ORP_` |
| Agents | `orp-chat`, `orp-writer`, `orp-full` |
| Writer sandbox | `%USERPROFILE%\Downloads\Opencode Reverse Proxy` |
| Default port | `8787` |
| Global config | `%USERPROFILE%\.config\opencode\opencode.json` |

## Workflow

Run every command with `powershell -ExecutionPolicy Bypass -File <script>`.

### 1. Install

```powershell
powershell -ExecutionPolicy Bypass -File scripts\install.ps1
```

Creates the writer sandbox and merges the three agents into the global OpenCode
config (backup first, re-runnable). OpenCode hot-reloads the config, so the
agents normally appear immediately; the script verifies this and only restarts
the OpenCode service as a fallback.

> A service restart terminates any OpenCode session that is running, including
> the one that invoked the installer. Hot reload makes this rare, but if you
> want to guarantee it never happens, pass `-NoRestart` and restart OpenCode
> Desktop yourself from a normal PowerShell window.

### 2. Start

```powershell
powershell -ExecutionPolicy Bypass -File scripts\start.ps1
```

Detached: returns in about two seconds and leaves the gateway running.
Options: `-Port`, `-Key`, `-DefaultModel`.

### 3. Verify

```powershell
powershell -ExecutionPolicy Bypass -File scripts\verify.ps1
```

Checks Node, the OpenCode service, agent registration, `/health`, the model
list, a non-stream chat, a Chinese UTF-8 round trip, a streaming chat, a sandbox
write, and a sandbox escape attempt. Exit code 0 means everything passed.

Use `-InstallOnly` to check only agent registration without needing the gateway
running.

### 4. Stop / Uninstall

```powershell
powershell -ExecutionPolicy Bypass -File scripts\stop.ps1
powershell -ExecutionPolicy Bypass -File scripts\uninstall.ps1
```

`uninstall.ps1` stops the gateway and removes the `orp-*` agents. Add
`-IncludeLegacy` to also remove stale pre-rename agents (`chat-api`,
`api-writer`, `api-full`) from `%USERPROFILE%\opencode.json`.

## Model routing

Append `@<agent>` to any model id. The available ids are listed by
`GET /v1/models`.

| Model spec | Agent | Capability |
|---|---|---|
| `big-pickle` | `orp-chat` | Text only. Every dangerous tool denied |
| `big-pickle@orp-writer` | `orp-writer` | Read/write files inside the sandbox only |
| `big-pickle@orp-full` | `orp-full` | Unrestricted: whole disk, shell, network |

The base model name is whatever OpenCode currently offers (for example
`big-pickle`, `deepseek-v4.1-flash-free`, `glm-5.3-flash-free`). Do not hardcode
a model list — query `/v1/models`; it changes over time.

## Two behaviours to tell the user about

1. **`@orp-writer` needs absolute paths.** The gateway forwards only the
   conversation text; it does not tell the model its working directory. Always
   give the full path in the prompt, for example
   `write to C:\Users\<you>\Downloads\Opencode Reverse Proxy\notes.md`.
   A bare filename makes the model guess and the sandbox rejects the guess.

2. **Tool calling is not passed through.** Requests carrying `tools` or
   `tool_choice` are accepted but answered as plain text, marked with
   `reverse_proxy.tools_ignored: true` (streaming: header
   `X-ORP-Tools-Ignored: 1`). The gateway never fabricates `tool_calls`.
   Clients that require real tool calls (for example Cline's tool panel) will
   not work; writing happens through the `@orp-writer` route instead.

## Security

The gateway binds `127.0.0.1` only. By default it does **not** check an API key,
and `orp-full` has no permission restrictions — any local process can read and
write the whole disk through it. If that is unacceptable, start with
`-Key "<random>"` and remove `orp-full` from `agents.json` before installing.

See `references/permissions.md` for the exact rule model.

## Client configuration

Base URL `http://127.0.0.1:8787/v1`, API key any non-empty value.
See `references/client-setup.md` for curl, the OpenAI Python/Node SDKs, and
which routes are not supported.
