#!/usr/bin/env node
/**
 * opencode-reverse-proxy — local OpenAI-compatible gateway that rides the genuine
 * OpenCode Desktop background service, so free Zen models are used through the
 * real OpenCode client (no identity spoofing, no upstream bypass).
 *
 *   External agent ──HTTP──> opencode-reverse-proxy (127.0.0.1:8787/v1)
 *                               │ HTTP Basic (reads service.json)
 *                               ▼
 *                    OpenCode Desktop service (127.0.0.1:<dynamic>)
 *                               │ genuine opencode client identity + login
 *                               ▼
 *                    https://opencode.ai/inference/... (free models)
 *
 * Endpoints:
 *   GET  /health                    liveness + upstream connection info
 *   GET  /v1/models                 free models currently offered by OpenCode
 *   GET  /v1/models/{id}            single model object
 *   POST /v1/chat/completions       OpenAI chat completions (stream + non-stream)
 *
 * Not supported (rejected with a clear error, not silently faked):
 *   - external OpenAI tool definitions (the OpenCode session API is agentic and
 *     cannot pass caller tools through to the upstream provider)
 *   - image inputs
 *   - /v1/responses, /v1/embeddings, /v1/messages
 *
 * Env vars:
 *   ORP_PORT            default 8787
 *   ORP_HOST            default 127.0.0.1
 *   ORP_KEY             optional; if set, clients must send it as Bearer token
 *   ORP_AGENT           default "orp-chat" (tool-less agent); "build" to disable override
 *   ORP_DEFAULT_MODEL   model id used when the caller sends no model
 *   ORP_TIMEOUT_MS      default 300000 (5 min per request)
 *   ORP_KEEP_SESSIONS   "1" to keep sessions in OpenCode instead of deleting them
 *   ORP_SERVICE_JSON    path to the OpenCode service registry
 *                         (default %USERPROFILE%\.local\state\opencode\service.json)
 */

import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";

const PORT = Number(process.env.ORP_PORT || 8787);
const HOST = process.env.ORP_HOST || "127.0.0.1";
const KEY = process.env.ORP_KEY || "";
const AGENT = process.env.ORP_AGENT || "orp-chat";
const DEFAULT_MODEL = process.env.ORP_DEFAULT_MODEL || "";
const TIMEOUT_MS = Number(process.env.ORP_TIMEOUT_MS || 300000);
const KEEP_SESSIONS = process.env.ORP_KEEP_SESSIONS === "1";
const STRIP_TOOLS = process.env.ORP_STRIP_TOOLS === "1";
const SERVICE_JSON = process.env.ORP_SERVICE_JSON || path.join(os.homedir(), ".local", "state", "opencode", "service.json");

const PROVIDER = "opencode";
const AGENTS_ALLOWLIST = String(process.env.ORP_AGENTS || "orp-chat,orp-writer,orp-full")
  .split(",").map((s) => s.trim()).filter(Boolean);

/** ---------- OpenCode service discovery ---------- */

let cached = { mtime: 0, url: null, auth: null, loadedAt: 0 };

function loadService(force = false) {
  let st = null;
  try {
    st = fs.statSync(SERVICE_JSON);
  } catch {
    return null;
  }
  if (!force && cached.url && cached.mtime === st.mtimeMs) return cached;
  let reg = null;
  try {
    reg = JSON.parse(fs.readFileSync(SERVICE_JSON, "utf8"));
  } catch {
    return null;
  }
  if (!reg || !reg.url || !reg.password) return null;
  cached = {
    mtime: st.mtimeMs,
    url: reg.url.replace(/\/+$/, ""),
    auth: "Basic " + Buffer.from(`opencode:${reg.password}`).toString("base64"),
    loadedAt: Date.now(),
  };
  return cached;
}

function invalidateService() {
  cached = { mtime: 0, url: null, auth: null, loadedAt: 0 };
}

async function oc(method, urlPath, { body, timeoutMs = 30000, signal } = {}) {
  const svc = loadService();
  if (!svc) {
    const e = new Error("OpenCode background service is not running. Open the OpenCode app and try again.");
    e.code = "SERVICE_UNAVAILABLE";
    throw e;
  }
  const run = async () => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    if (signal) {
      if (signal.aborted) controller.abort();
      else signal.addEventListener("abort", () => controller.abort(), { once: true });
    }
    try {
      const res = await fetch(svc.url + urlPath, {
        method,
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          "Authorization": svc.auth,
        },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal,
      });
      if (res.status === 204) return { status: 204, data: null };
      const text = await res.text();
      let data = null;
      try {
        data = text ? JSON.parse(text) : null;
      } catch {
        data = text;
      }
      if (res.status >= 400) {
        const msg = typeof data === "object" && data ? (data.message || data.error?.message || JSON.stringify(data)) : String(data || res.statusText);
        const e = new Error(msg);
        e.code = "UPSTREAM_" + res.status;
        e.status = res.status;
        throw e;
      }
      return { status: res.status, data };
    } finally {
      clearTimeout(timer);
    }
  };
  try {
    return await run();
  } catch (e) {
    // The dedicated service may be restarted by the app (new port / new password).
    if (e.code === "UPSTREAM_401" || e.name === "TypeError") {
      invalidateService();
      const fresh = loadService(true);
      if (fresh && fresh.url !== svc.url) {
        return await run();
      }
    }
    throw e;
  }
}

/** ---------- message flattening ---------- */

function contentToText(content) {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    const out = [];
    for (const p of content) {
      if (!p) continue;
      if (p.type === "text" && p.text) out.push(p.text);
      else if (p.type === "image" || p.type === "image_url") out.push("[binary image content omitted]");
    }
    return out.join("\n");
  }
  if (content == null) return "";
  return String(content);
}

function buildPrompt(messages) {
  const instr = [];
  const turn = [];
  for (const m of messages || []) {
    const t = contentToText(m.content);
    if (m.role === "system" || m.role === "developer") instr.push(t);
    else if (m.role === "user") turn.push(["User", t]);
    else if (m.role === "assistant") turn.push(["Assistant", t]);
    else if (m.role === "tool" || m.role === "function") turn.push([`${m.role} result${m.tool_call_id ? " for " + m.tool_call_id : ""}`, t]);
  }
  const parts = [];
  if (instr.length) parts.push(`<instructions>\n${instr.join("\n\n")}\n</instructions>`);
  if (turn.length === 0) throw new ClientHttpError(400, "invalid_request_error", "messages must contain at least one user/assistant message");
  if (turn.length === 1 && turn[0][0] === "User") {
    parts.push(turn[0][1]);
  } else {
    parts.push(turn.map(([role, t]) => `${role}: ${t}`).join("\n\n"));
  }
  return parts.join("\n\n");
}

/** ---------- errors ---------- */

class ClientHttpError extends Error {
  constructor(status, type, message, param) {
    super(message);
    this.status = status;
    this.type = type;
    this.param = param;
  }
}

function errorBody(e) {
  if (e instanceof ClientHttpError) {
    return { error: { message: e.message, type: e.type, code: e.status === 404 ? "model_not_found" : e.type, param: e.param } };
  }
  if (e.code === "SERVICE_UNAVAILABLE") {
    return { error: { message: e.message, type: "upstream_unavailable", code: "opencode_service_not_found" } };
  }
  if (e.code === "UPSTREAM_403") {
    return { error: { message: "OpenCode rejected this request (403). This gateway routes through the genuine OpenCode client; if you see this, the client session was rejected upstream (e.g. free-tier quota). Details: " + e.message, type: "upstream_error", code: "free_tier_error" } };
  }
  return { error: { message: e.message || String(e), type: "gateway_error" } };
}

/** ---------- helpers ---------- */

async function listModels() {
  const { data } = await oc("GET", "/api/model");
  const items = (data?.data || []).filter(
    (m) => m.providerID === PROVIDER && m.enabled && m.status === "active",
  );
  return items;
}

function resolveModel(items, wanted) {
  // model spec may carry an "@<agent>" suffix, e.g. "big-pickle@writer";
  // the agent must appear in the ORP_AGENTS allowlist
  const raw = String(wanted || "");
  const at = raw.lastIndexOf("@");
  let modelName = raw;
  let agent = "";
  if (at > 0) {
    modelName = raw.slice(0, at);
    agent = raw.slice(at + 1);
    if (!AGENTS_ALLOWLIST.includes(agent)) {
      throw new ClientHttpError(400, "invalid_request_error", `unknown agent '${agent}' in model spec. Allowed: ${AGENTS_ALLOWLIST.join(", ")}`);
    }
  }
  const model = resolveModelId(items, modelName);
  return { model, agent: agent || AGENT };
}

function resolveModelId(items, wanted) {
  const norm = (s) => String(s || "").trim().toLowerCase();
  const clean = norm(wanted).replace(/^opencode\//, "");
  if (clean) {
    const hit =
      items.find((m) => norm(m.id) === clean) ||
      items.find((m) => norm(m.modelID) === clean) ||
      items.find((m) => norm(m.name) === norm(wanted)) ||
      items.find((m) => norm(m.id).replace(/^opencode\//, "").startsWith(clean));
    if (!hit) {
      const avail = items.map((m) => m.id).join(", ");
      throw new ClientHttpError(404, "invalid_request_error", `model '${wanted}' is not available. Available free models: ${avail || "(none right now)"}`);
    }
    return hit;
  }
  if (DEFAULT_MODEL) {
    const hit = items.find((m) => norm(m.id) === norm(DEFAULT_MODEL).replace(/^opencode\//, ""));
    if (hit) return hit;
  }
  if (!items.length) {
    throw new ClientHttpError(503, "upstream_unavailable", "OpenCode currently reports no active free models.");
  }
  return items[0];
}

const now = () => Math.floor(Date.now() / 1000);

/** create session, set agent + model */
async function prepareSession(modelId, agent = AGENT) {
  const created = await oc("POST", "/api/session", { body: {} });
  const sid = created.data?.data?.id || created.data?.id;
  if (agent && agent !== "build") {
    try {
      await oc("POST", `/api/session/${sid}/agent`, { body: { agent } });
    } catch (e) {
      if (KEEP_SESSIONS !== true) await oc("DELETE", `/api/session/${sid}`).catch(() => {});
      throw e;
    }
  }
  try {
    await oc("POST", `/api/session/${sid}/model`, { body: { model: { providerID: PROVIDER, id: modelId } } });
  } catch {
    // keep the session's default model if the switch fails
  }
  return sid;
}

async function destroySession(sid) {
  if (KEEP_SESSIONS) return;
  await oc("DELETE", `/api/session/${sid}`).catch(() => {});
}

function extractAssistantText(msg) {
  return (msg.content || [])
    .filter((c) => c.type === "text" && c.text)
    .map((c) => c.text)
    .join("");
}

function timeComparable(m) {
  return m.time?.streamed || m.time?.created;
}

function usageOf(msg) {
  const t = msg.tokens || {};
  return {
    prompt_tokens: t.input || 0,
    completion_tokens: t.output || 0,
    reasoning_tokens: t.reasoning || 0,
    total_tokens: (t.input || 0) + (t.output || 0),
  };
}

/** ---------- HTTP plumbing ---------- */

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(body);
}

function readBody(req, limit = 16 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > limit) {
        reject(new ClientHttpError(413, "invalid_request_error", "request body too large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function authorized(req) {
  if (!KEY) return true;
  const h = req.headers.authorization || "";
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return Boolean(m && m[1] === KEY);
}

/** ---------- /health ---------- */

async function handleHealth(res) {
  try {
    const svc = loadService(true);
    if (!svc) return sendJson(res, 503, { ok: false, error: "OpenCode background service not found (is the OpenCode app running?)" });
    await oc("GET", "/api/info", { timeoutMs: 5000 });
    sendJson(res, 200, { ok: true, gateway: "opencode-reverse-proxy", opencodeService: svc.url, agent: AGENT });
  } catch (e) {
    sendJson(res, 503, { ok: false, error: e.message });
  }
}

/** ---------- /v1/models ---------- */

async function handleModels(res) {
  const items = await listModels();
  sendJson(res, 200, {
    object: "list",
    data: items.flatMap((m) => {
      const base = {
        id: m.id,
        object: "model",
        created: m.time?.released ? Math.floor(m.time.released / 1000) : 0,
        owned_by: "opencode",
        context_length: m.limit?.context,
        max_output_tokens: m.limit?.output,
      };
      const variants = [base];
      for (const suffixAgent of AGENTS_ALLOWLIST) {
        if (suffixAgent === AGENT) continue;
        variants.push({ ...base, id: `${m.id}@${suffixAgent}`, owned_by: `opencode/${suffixAgent}` });
      }
      return variants;
    }),
  });
}

async function handleModelGet(res, id, items) {
  const hit = items.find((m) => m.id === id);
  if (!hit) return sendJson(res, 404, errorBody(new ClientHttpError(404, "invalid_request_error", `model '${id}' not found`)));
  sendJson(res, 200, {
    id: hit.id,
    object: "model",
    created: hit.time?.released ? Math.floor(hit.time.released / 1000) : 0,
    owned_by: "opencode",
  });
}

/** ---------- /v1/chat/completions (non-stream) ---------- */

async function chatNonStream(res, body, toolsIgnored = false) {
  const items = await listModels();
  const { model, agent } = resolveModel(items, body.model);
  const prompt = buildPrompt(body.messages);
  const sid = await prepareSession(model.id, agent);
  try {
    await oc("POST", `/api/session/${sid}/prompt`, { body: { text: prompt, delivery: "steer" } });
    await oc("POST", `/api/experimental/session/${sid}/wait`, { timeoutMs: TIMEOUT_MS, body: {} });
    const { data } = await oc("GET", `/api/session/${sid}/message`, { timeoutMs: 15000 });
    const messages = data?.data || [];
    const assistant =
      messages.find((m) => m.type === "assistant" && (m.time?.completed || timeComparable(m))) ||
      messages.find((m) => m.type === "assistant");
    if (!assistant) {
      throw new Error("no assistant message produced (session may have been interrupted)");
    }
    if (assistant.finish === "error") {
      destroySession(sid);
      throw new Error("upstream model error: " + (assistant.error?.message || assistant.error?.type || "unknown model failure"));
    }
    const text = extractAssistantText(assistant);
    const finish = "stop"; // tool calls are not supported, so the finish reason is always "stop"
    const servedModel = assistant.model?.id || model.id;
    sendJson(res, 200, {
      id: "chatcmpl-" + (assistant.id || sid),
      object: "chat.completion",
      created: assistant.time?.completed ? Math.floor(assistant.time.completed / 1000) : now(),
      model: servedModel,
      choices: [
        {
          index: 0,
          message: { role: "assistant", content: text },
          finish_reason: finish,
        },
      ],
      usage: usageOf(assistant),
      openai_compatible: true,
      reverse_proxy: { sessionID: sid, providerID: PROVIDER, ...(toolsIgnored ? { tools_ignored: true } : {}) },
    });
  } finally {
    destroySession(sid);
  }
}

/** ---------- /v1/chat/completions (stream) ---------- */

async function chatStream(res, body, toolsIgnored = false) {
  const items = await listModels();
  const { model, agent } = resolveModel(items, body.model);
  const prompt = buildPrompt(body.messages);
  const sid = await prepareSession(model.id, agent);
  const wantUsage = Boolean(body.stream_options?.include_usage);
  const includeReasoning = false === false && ""; // reasoning deltas are emitted as reasoning_content when the model streams them
  void includeReasoning;

  const modelId = model.id || body.model;
  const id = "chatcmpl-" + sid + "-" + now();
  let closed = false;
  res.on("close", () => {
    closed = true;
  });

  const writeChunk = (delta, finishReason = null, usage) => {
    if (closed) return;
    const chunk = {
      id,
      object: "chat.completion.chunk",
      created: now(),
      model: modelId,
      choices: [{ index: 0, delta, finish_reason: finishReason }],
    };
    if (usage) chunk.usage = usage;
    res.write(`data: ${JSON.stringify(chunk)}\n\n`);
  };

  // open SSE first so no early deltas are missed
  const ac = new AbortController();
  const onClose = () => ac.abort();
  res.on("close", onClose);
  let sse;
  try {
    sse = await fetch(cached.url.replace(/\/+$/, "") + "/api/event", {
      headers: { "Authorization": cached.auth, "Accept": "text/event-stream" },
      signal: ac.signal,
    });
    if (!sse.ok || !sse.body) throw new Error(`event stream status ${sse.status}`);
    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive",
      "X-Accel-Buffering": "no",
      ...(toolsIgnored ? { "X-ORP-Tools-Ignored": "1" } : {}),
    });
    await oc("POST", `/api/session/${sid}/prompt`, { body: { text: prompt, delivery: "steer" } });

    const decode = sse.body.pipeThrough(new TextDecoderStream());
    const reader = decode.getReader();
    let buf = "";
    let usage = null;
    let done = false;
    writeChunk({ role: "assistant", content: "" });

    while (!done) {
      const { value, done: rdDone } = await reader.read();
      if (rdDone) break;
      if (closed) break;
      buf += value;
      let idx;
      while ((idx = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, idx).replace(/\r$/, "");
        buf = buf.slice(idx + 1);
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload) continue;
        let evt = null;
        try {
          evt = JSON.parse(payload);
        } catch {
          continue;
        }
        if (evt.type === "session.connected" || !evt.data || evt.data.sessionID !== sid) continue;
        switch (evt.type) {
          case "session.reasoning.delta":
            writeChunk({ reasoning_content: evt.data.delta });
            break;
          case "session.text.delta":
            writeChunk({ content: evt.data.delta });
            break;
          case "session.usage.updated":
            usage = {
              prompt_tokens: evt.data.tokens?.input || 0,
              completion_tokens: evt.data.tokens?.output || 0,
              reasoning_tokens: evt.data.tokens?.reasoning || 0,
              total_tokens: (evt.data.tokens?.input || 0) + (evt.data.tokens?.output || 0),
            };
            break;
          case "session.execution.succeeded":
            if (wantUsage && usage) writeChunk({}, null, usage);
            writeChunk({}, "stop");
            done = true;
            break;
          case "session.execution.failed":
          case "session.execution.interrupted": {
            writeChunk({ content: "\n[opencode-reverse-proxy] the OpenCode session ended with an error before completing the response." }, "stop");
            done = true;
            break;
          }
        }
      }
    }
    if (!closed) res.write("data: [DONE]\n\n");
    res.end();
  } catch (e) {
    if (!closed && !res.writableEnded) {
      try {
        if (!res.headersSent) {
          sendJson(res, 502, errorBody(e));
        } else {
          res.end();
        }
      } catch {
        /* ignore */
      }
    }
  } finally {
    res.off("close", onClose);
    try {
      ac.abort();
    } catch {}
    await destroySession(sid);
  }
}

/** ---------- server ---------- */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  const p = url.pathname;

  if (!authorized(req)) {
    return sendJson(res, 401, { error: { message: "invalid or missing API key", type: "invalid_request_error" } });
  }

  try {
    if (p === "/health" && req.method === "GET") return await handleHealth(res);
    if (p === "/" && req.method === "GET") {
      return sendJson(res, 200, {
        gateway: "opencode-reverse-proxy",
        routes: { health: "/health", models: "/v1/models", chat: "/v1/chat/completions" },
        note: "OpenAI-compatible gateway riding the genuine OpenCode client. Tools are not supported; use text chat.",
      });
    }
    if (p === "/v1/models" && req.method === "GET") return await handleModels(res);
    if (p.startsWith("/v1/models/") && req.method === "GET") {
      const items = await listModels();
      return await handleModelGet(res, decodeURIComponent(p.slice("/v1/models/".length)), items);
    }
    if (p === "/v1/chat/completions" && req.method === "POST") {
      const raw = await readBody(req);
      let body;
      try {
        body = JSON.parse(raw);
      } catch {
        return sendJson(res, 400, { error: { message: "request body is not valid JSON", type: "invalid_request_error" } });
      }
      let toolsIgnored = false;
      if (body.tools || body.tool_choice) {
        if (STRIP_TOOLS) {
          // Compatibility mode: accept the request, ignore tool definitions, answer in text.
          // Disclosed to the client via the response marker below — never faked as executed.
          body = { ...body, tools: undefined, tool_choice: undefined };
          toolsIgnored = true;
        } else {
          return sendJson(res, 400, {
            error: {
              message: "tools are not supported by this gateway: requests ride the genuine OpenCode client, whose session API cannot execute external OpenAI tool definitions. Send the request without 'tools'/'tool_choice' (text answer only), enable the gateway's ORP_STRIP_TOOLS=1 compatibility mode, or use an official OpenCode Zen API key against https://opencode.ai/inference for full tool calling.",
              type: "invalid_request_error",
              param: body.tools ? "tools" : "tool_choice",
            },
          });
        }
      }
      if (!Array.isArray(body.messages) || !body.messages.length) {
        return sendJson(res, 400, { error: { message: "'messages' must be a non-empty array", type: "invalid_request_error", param: "messages" } });
      }
      return body.stream ? await chatStream(res, body, toolsIgnored) : await chatNonStream(res, body, toolsIgnored);
    }
    if (p === "/v1/responses" || p === "/v1/messages" || p === "/v1/embeddings") {
      return sendJson(res, 400, {
        error: { message: `${p} is not available on this gateway. Only /v1/models and /v1/chat/completions are supported.`, type: "invalid_request_error" },
      });
    }
    if (p === "/v1" || p === "/v1/") return await handleModels(res); // some friendship with clients hitting the bare base
    return sendJson(res, 404, { error: { message: `no route: ${req.method} ${p}`, type: "invalid_request_error" } });
  } catch (e) {
    return sendJson(res, (e instanceof ClientHttpError && e.status) || e.status === 400 || e.status === 403 || e.status === 503 ? e.status || 500 : 502, errorBody(e));
  }
});

server.listen(PORT, HOST, () => {
  console.log(`[opencode-reverse-proxy] listening on http://${HOST}:${PORT}/v1`);
  const svc = loadService();
  console.log(`[opencode-reverse-proxy] opencode service: ${svc ? svc.url : "NOT FOUND - launch the OpenCode Desktop app"}`);
  console.log(`[opencode-reverse-proxy] agent: ${AGENT} | agents allowlist: ${AGENTS_ALLOWLIST.join(",")} | key: ${KEY ? "required" : "not required"} | tools requests: ${STRIP_TOOLS ? "accepted, tools ignored (compat mode)" : "rejected with 400"}`);
});

server.on("error", (e) => {
  if (e.code === "EADDRINUSE") {
    console.error(`[opencode-reverse-proxy] port ${PORT} is already in use. Another gateway instance may be running.`);
    process.exit(1);
  }
  console.error("[opencode-reverse-proxy] server error:", e.message);
  process.exit(1);
});

process.on("SIGINT", () => server.close(() => process.exit(0)));
