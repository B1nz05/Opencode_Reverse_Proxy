# Client setup

The gateway speaks the OpenAI Chat Completions API.

| Setting | Value |
|---|---|
| Base URL | `http://127.0.0.1:8787/v1` |
| API key | any non-empty string (ignored unless the gateway was started with `-Key`) |
| Model | any id from `GET /v1/models` |

List the models first — the set of free models changes over time:

```powershell
curl.exe http://127.0.0.1:8787/v1/models
```

## curl

```powershell
curl.exe http://127.0.0.1:8787/v1/chat/completions `
  -H "Content-Type: application/json" `
  -d '{\"model\":\"big-pickle\",\"messages\":[{\"role\":\"user\",\"content\":\"hello\"}]}'
```

Streaming:

```powershell
curl.exe -N http://127.0.0.1:8787/v1/chat/completions `
  -H "Content-Type: application/json" `
  -d '{\"model\":\"big-pickle\",\"stream\":true,\"messages\":[{\"role\":\"user\",\"content\":\"hello\"}]}'
```

## OpenAI Python SDK

```python
from openai import OpenAI

client = OpenAI(base_url="http://127.0.0.1:8787/v1", api_key="local")

resp = client.chat.completions.create(
    model="big-pickle",
    messages=[{"role": "user", "content": "hello"}],
)
print(resp.choices[0].message.content)
```

## OpenAI Node SDK

```js
import OpenAI from "openai";

const client = new OpenAI({ baseURL: "http://127.0.0.1:8787/v1", apiKey: "local" });

const resp = await client.chat.completions.create({
  model: "big-pickle",
  messages: [{ role: "user", content: "hello" }],
});
console.log(resp.choices[0].message.content);
```

## Writing files through `@orp-writer`

The gateway does not tell the model its working directory. Always pass an
absolute path:

```python
client.chat.completions.create(
    model="big-pickle@orp-writer",
    messages=[{
        "role": "user",
        "content": "Use the write tool to create C:/Users/me/Downloads/Opencode Reverse Proxy/notes.md with the content: hello",
    }],
)
```

The write happens inside the OpenCode service. The HTTP response contains the
model's text summary, not the file contents.

## Supported routes

| Route | Status |
|---|---|
| `GET /health` | supported |
| `GET /v1/models` | supported |
| `GET /v1/models/{id}` | supported |
| `POST /v1/chat/completions` | supported (stream and non-stream) |
| `POST /v1/responses` | not supported (clear 400) |
| `POST /v1/messages` | not supported (clear 400) |
| `POST /v1/embeddings` | not supported (clear 400) |

## Response extras

Non-streaming responses carry:

```json
"reverse_proxy": { "sessionID": "ses_...", "providerID": "opencode", "tools_ignored": true }
```

`tools_ignored` appears only when the request contained `tools`/`tool_choice`
and the gateway stripped them. Streaming responses signal the same thing with
the `X-ORP-Tools-Ignored: 1` response header.

## PowerShell clients

PowerShell 5.1 decodes `application/json` responses as Latin-1 when no charset
is present. The gateway sends `charset=utf-8`, so `Invoke-RestMethod` is fine.
If you hit an older build, write to a file and read it back as UTF-8:

```powershell
Invoke-WebRequest ... -OutFile resp.json
[IO.File]::ReadAllText("resp.json", [Text.Encoding]::UTF8)
```
