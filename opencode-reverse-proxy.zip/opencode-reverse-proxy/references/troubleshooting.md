# Troubleshooting

Run `scripts\verify.ps1` first; it names the failing layer.

## The gateway will not start

**`port 8787 is already in use`**
Something else owns the port, or an older gateway is still running.

```powershell
Get-NetTCPConnection -LocalPort 8787 -State Listen | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }
```

**`OpenCode background service is not running`**
Start OpenCode Desktop and sign in. The gateway has no credentials of its own;
it reads `%USERPROFILE%\.local\state\opencode\service.json`.

**`node` is not recognized**
Install Node.js 18 or newer and reopen the terminal.

## The agents do not exist

`install.ps1` writes to `%USERPROFILE%\.config\opencode\opencode.json`. A file at
`%USERPROFILE%\opencode.json` is discovered as an ancestor config and **wins**
over the global one for anything under the home directory. If it still defines
old agents, remove them:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\uninstall.ps1 -IncludeLegacy
```

Then confirm registration:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\verify.ps1 -InstallOnly
```

If the agents are still missing, restart OpenCode Desktop. A config change is
not guaranteed to hot-reload into the running service.

**Do not restart the OpenCode service from inside an OpenCode session** — the
restart kills that session. Use a normal PowerShell window, or pass
`-NoRestart` and restart the desktop app yourself.

## `/v1/models` is empty or 503

OpenCode reports no active free models. Open OpenCode Desktop and confirm you
can chat with a free model. If the model list in the app is empty, the account
has no free tier and the gateway cannot help.

## Requests hang, then fail

The gateway waits up to `ORP_TIMEOUT_MS` (default 300 s) for the session to
finish. Long reasoning models can exceed that; raise it:

```powershell
$env:ORP_TIMEOUT_MS = "600000"
powershell -ExecutionPolicy Bypass -File scripts\start.ps1
```

## Streaming stops mid-answer with no error

If the OpenCode service restarts while a stream is open, the SSE connection
drops and the gateway closes the stream with `[DONE]` rather than an error. The
answer is truncated but looks complete. Re-send the request.

This is a known limitation of the streaming path: it connects to the service
address cached at request start and does not re-discover it. The non-streaming
path does retry after a 401.

## `@orp-writer` refuses to write

Almost always a path problem, not a permission problem:

1. Send an **absolute** path, for example
   `C:/Users/me/Downloads/Opencode Reverse Proxy/notes.md`.
2. Keep it inside the sandbox. The gateway stamps the sandbox root into the
   agent at install time; changing `-WriterDir` later requires reinstalling.
3. A relative name such as `notes.md` resolves against the OpenCode service's
   working directory, which is not the sandbox, so it is denied.

If the path is correct and still denied, check that the installed rules point to
the right folder:

```powershell
(Get-Content "$env:USERPROFILE\.config\opencode\opencode.json" -Raw | ConvertFrom-Json).agents.'orp-writer'.permissions |
  Format-Table action, resource, effect
```

## Chinese or other non-ASCII text comes back garbled

The gateway now sends `Content-Type: application/json; charset=utf-8`. If you
still see mojibake, the client is decoding as Latin-1. In PowerShell 5.1, write
the response to a file and read it back as UTF-8, or use `curl.exe`.

## `tools` requests behave unexpectedly

By default the gateway strips `tools`/`tool_choice`, answers as plain text, and
marks the response (`reverse_proxy.tools_ignored` / `X-ORP-Tools-Ignored: 1`).
It never returns fake `tool_calls`.

Start the gateway without `ORP_STRIP_TOOLS` to reject such requests with a 400
instead of silently answering in text.

## Everything looks fine but the client gets 401

The gateway was started with `-Key`. Send `Authorization: Bearer <key>`.

## Logs

```
%LOCALAPPDATA%\opencode-reverse-proxy\gateway.out.log
%LOCALAPPDATA%\opencode-reverse-proxy\gateway.err.log
```

The OpenCode service log is at `%LOCALAPPDATA%\opencode\log\opencode.log` on
most installs; filter for `role=server` when the failure is on the OpenCode
side.
