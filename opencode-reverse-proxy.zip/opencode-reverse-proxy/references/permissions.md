# Permissions

The gateway does not run tools itself. It asks the OpenCode service to run a
session with one of three agents, and OpenCode enforces that agent's permission
rules. The gateway's `@<agent>` model suffix is how you choose the agent.

## The three agents

### `orp-chat` — default, text only

Every capability that can touch the machine is denied individually: shell,
edit, execute, glob, grep, webfetch, websearch, skill, subagent, question,
external_directory, browser, and the MCP resource tools. Reads of `*.env`,
`*.env.*`, `*.pem`, and `*.key` are denied as well.

Use it for plain conversation and for anything you do not fully trust.

### `orp-writer` — sandboxed file access

Deny-all first, then specific allows. OpenCode uses the **last matching rule**,
so the allows must come after the deny.

```jsonc
[
  { "action": "*", "resource": "*", "effect": "deny" },
  { "action": "external_directory", "resource": "<WRITER_DIR>/*", "effect": "allow" },
  { "action": "read",               "resource": "<WRITER_DIR>/*", "effect": "allow" },
  { "action": "edit",               "resource": "<WRITER_DIR>/*", "effect": "allow" },
  { "action": "glob",               "resource": "<WRITER_DIR>/*", "effect": "allow" }
]
```

`<WRITER_DIR>` is stamped in at install time from `-WriterDir`, defaulting to
`%USERPROFILE%\Downloads\Opencode Reverse Proxy`. The path is written with
forward slashes because OpenCode normalizes paths before matching.

The `external_directory` allow is required: the sandbox lives outside the
session's working directory, and without it every access would be denied
before the read/edit rules are consulted.

**Known limitation — `glob` does not work.** In OpenCode V2 the `glob` action's
resource is the *glob pattern the model asks for* (for example `**/*.md`), not
a directory path. A path-shaped rule never matches. `orp-writer` can still read
and write when given explicit paths, but it cannot enumerate the directory.
This is left as-is by design; fix it only if you are willing to maintain a fork.

**Known limitation — no working directory.** The gateway forwards only the
conversation text. The model is not told which directory the session uses, so
a bare filename like `notes.md` makes it guess, and the sandbox rejects the
guess. Always send absolute paths.

### `orp-full` — unrestricted

No permission rules beyond the OpenCode base policy. The model can read and
write anywhere the user can, run shell commands, and fetch URLs.

This is a genuine local privilege boundary, not a theoretical one: combined
with the default "no API key" setting, **any local process can use it to
execute commands as the logged-in user**.

## Reducing the risk

Start the gateway with a key:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\start.ps1 -Key "a-long-random-string"
```

Clients must then send `Authorization: Bearer <key>`.

Remove the `orp-full` entry from `agents.json` before installing if you do not
need it. Reinstall after editing; the installer replaces agent definitions by
name.

## What the gateway will not do

- Bind to anything other than `127.0.0.1` by default (`-Host` exists, but do not
  set it to `0.0.0.0`).
- Fabricate `tool_calls`.
- Pass the caller's `tools` definitions to the upstream provider. The OpenCode
  session API is agentic; it cannot execute external OpenAI tool definitions.
- Forward images. They are replaced with `[binary image content omitted]`.
- Retry or work around 429/403 quota errors. They are passed through.
